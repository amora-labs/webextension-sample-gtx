/*
 GTX

 Se precisar de JS, coloque nesse arquivo aqui.
 */